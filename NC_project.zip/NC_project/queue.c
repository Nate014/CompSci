//
// Created by natha on 2024-11-20.
//

#include "queue.h"

#include <stdio.h>

#include "stdlib.h"



QUEUE_P* create_priority_queue() {
    QUEUE_P* qp = (QUEUE_P*)malloc(sizeof(QUEUE_P));
    qp->length = 0;
    qp->front= NULL;
    return qp;
}

//Creates new tree node
node_t* create_node(int index, unsigned int weight) {
    node_t* node = (node_t*)malloc(sizeof(node_t));
    node->index = index;
    node->weight = weight;
    node->left = NULL;
    node->right = NULL;
    node->next = NULL;
    return node;
}

void enqueue(QUEUE_P *qp, node_t* new_node) {
    if (qp->front == NULL || qp->front->weight > new_node->weight) {//Insert at front of list
        new_node->next = qp->front;
        qp->front = new_node;
    }
    else {//Find where to insert
        node_t* current = qp->front;
        while (current->next != NULL && current->next->weight <= new_node->weight) {
            current = current->next;
        }
        //Insert into found position
        new_node->next = current->next;
        current->next = new_node;
    }
    qp->length++;
}
node_t* dequeue(QUEUE_P *qp) {
    if (qp->front == NULL){
    return NULL;
    }
    node_t* temp = qp->front;
    qp->front = qp->front->next;
    temp->next = NULL;//Get rid of next pointer(Now it becomes a huffman tree node)
    return temp;
}

//Clean queue
void queue_clean(QUEUE_P *qp) {
    if (qp->front == NULL) {
        return;
    }
    node_t* temp = qp->front;
    while (temp != NULL) {
        node_t* next = temp->next;
        free(temp);
        temp = next;
    }
    qp->front = NULL;
    qp->length = 0;
}

node_t* huffman_tree(int frequencies[], int n) {
    QUEUE_P* qp = create_priority_queue();

    //Create leaf nodes for characters with non-zero frequencies and enqueue them
    for (int i = 0; i < n; i++) {
        if (frequencies[i] > 0) {
            enqueue(qp, create_node(i, frequencies[i]));
        }
    }

    if (qp->length == 1) {
        node_t* left = dequeue(qp); // Only character
        node_t* root = create_node(-1, left->weight); // Root with combined weight
        root->left = left;  // Assign the only character as left child
        root->right = create_node(-1, 0); // Dummy right child to maintain tree structure
        return root;
    }

    //Build the Huffman tree
    while (qp->front!= NULL && qp->front->next != NULL) {
        //Dequeue two smallest nodes
        node_t* left = dequeue(qp);
        node_t* right = dequeue(qp);

        //Create a new internal node with combined weight
        node_t* new_node = create_node(-1, left->weight + right->weight);
        new_node->left = left;
        new_node->right = right;

        //Enqueue the new node back into the priority queue
        enqueue(qp, new_node);
    }

    //Remaining node is the root of the Huffman tree
    node_t* root = dequeue(qp);

    queue_clean(qp);
    //Return the root for huffman tree
    return root;
}

