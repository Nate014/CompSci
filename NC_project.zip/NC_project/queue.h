//
// Created by natha on 2024-11-20.
//

#ifndef QUEUE_H
#define QUEUE_H

#endif //QUEUE_H



// A Huffman tree node
typedef struct node_t{
    int index;
    unsigned int weight;
    struct node_t *left;
    struct node_t *right;
    struct node_t *next;
} node_t;

//Array based queue
typedef struct queue {
    int length;
    node_t *front;
}QUEUE_P;


QUEUE_P* create_priority_queue();
void enqueue(QUEUE_P *qp, node_t* new_node);
node_t *dequeue(QUEUE_P *qp);
node_t* huffman_tree(int frequencies[], int n);
void queue_clean(QUEUE_P *qp);

