/*
* CS1037 Huffman Coding
 *
 * This file contains the main program,the structure of the Huffman node
 * and user interface for running your Huffman Encoder/Decoder.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue.h"

int mystrlen(char *p)
{
    int c=0;
    while(*p!='\0')
    {
        c++;
        *p++;
    }
    return(c);
}

int count_weight(node_t *root, char* code_table[]) {
    int count = 0;
    if (root == NULL) {
        return 0;
    }
    if (root->index != -1) {
        printf("num: %d\n", atoi(code_table[root->index]));
        int l = mystrlen(code_table[root->index]);
        printf("Number: %d\n", l);
        printf("weight: %d\n",root->weight);
        printf("Total: %d\n", root->weight*l);
        count += (root->weight)*l;
        return count;
    }
    count += count_weight(root->left,code_table);
    count += count_weight(root->right,code_table);
    return count;
}

void free_code_table(char* code_table[]) {
    for (int i = 0; i < 128; ++i) {
        free(code_table[i]); // Free each dynamically allocated string
        code_table[i] = NULL;
    }
}

//Will go through every possible path and generate codes for the respective path character
void generate_codes(node_t* root, char* code, int depth, char* code_table[]) {
    if (root==NULL) {
        return;
    }

    if (root->index != -1) {//At a leaf node
        code[depth] = '\0';//Add end of line character
        code_table[root->index] = strdup(code); //strdub will store each code interdependently in memory
    } else {//recursive traverse
        //Go left
        code[depth] = '0';
        generate_codes(root->left, code, depth + 1, code_table);

        //Go right
        code[depth] = '1';
        generate_codes(root->right, code, depth + 1, code_table);
    }
}

//Writes the huffman tree into file in order for decompression later
void write_tree(FILE* out, node_t* root) {
    if (!root) {
        return;
    }

    if (root->index != -1) { //Leaf node
        fputc('1', out);
        fputc(root->index, out);
    } else {//Internal node
        fputc('0', out);
        write_tree(out, root->left);
        write_tree(out, root->right);
    }
}

void compress_file(FILE* in, FILE* out, char* code_table[],int tweight) {
    int bit_count = 0;
    unsigned char byte = 0;
    int c;
    fwrite(&tweight, sizeof(int), 1, out);
    while ((c = fgetc(in)) != EOF) {
        const char* code = code_table[c]; // Get the Huffman code for the character
        for (const char* p = code; *p != '\0'; ++p) {
            if (*p == '1') {
                byte |= (1 << (7 - bit_count)); // Set the bit
            }
            bit_count++;

            if (bit_count == 8) { // Write a full byte to the file
                printf("Hello");
                fputc(byte, out);
                bit_count = 0;
                byte = 0;
            }
        }
    }

    // Write any remaining bits
    if (bit_count > 0) {
        fputc(byte, out);
    }
}

void encode(char *iFile, char *oFile) {
    //Build Frequency table
    int frequency[128] = {0};
    FILE *in = fopen(iFile, "r");//Open file
    if (in == NULL) {//Error handle
        printf("Error opening input file\n");
        exit(1);
    }
    char c;
    while((c = fgetc(in)) != EOF) {//sets c = to the next character in file and checks for EOF
        frequency[c]++;//Increments the number at given letter cell
    }
    fclose(in);

    //Hoffman tree root
    node_t *root = huffman_tree(frequency,128);
    //Codes
    char* code_table[128] = {0}; // Lookup table for codes
    char code[128];
    generate_codes(root, code, 0, code_table);
    int tweight = count_weight(root,code_table);

    //To see whats happening
    printf("code_table:\n");
    printf("%c\n", root->index);
    for (int i = 0; i < 128; ++i) {
        if (code_table[i] != NULL) {
            printf("code_table[%c]: %s\n", i, code_table[i]);

        }
    }

    //Write huffman tree to output file
    FILE* out = fopen("output.huf", "wb");
    if (out == NULL) {
        printf("Error opening output file\n");
        exit(1);
    }
    in = fopen("Test.txt", "r");
    if (in == NULL) {
        printf("Error opening input file\n");
        exit(1);
    }
    //Print huffman tree to the file
    write_tree(out, root);

    compress_file(in, out, code_table,tweight);

    fclose(in);
    fclose(out);

    free_code_table(code_table);//Free memory
}


node_t *read_tree(FILE *in) {
    int marker = fgetc(in);
    if (marker == EOF) return NULL;

    if (marker == '1') { // Leaf node
        int character = fgetc(in);
        node_t *leaf = malloc(sizeof(node_t));
        leaf->index = character;
        leaf->left = leaf->right = NULL;
        return leaf;
    } else if (marker == '0') { // Internal node
        node_t *internal = malloc(sizeof(node_t));
        internal->index = -1;
        internal->left = read_tree(in);
        internal->right = read_tree(in);
        return internal;
    }

    return NULL;
}

int get_valid_bits(FILE *in) {
    fseek(in, -1, SEEK_END); // Move to the last byte
    int valid_bits = fgetc(in); // Read the valid bits metadata
    fseek(in, 0, SEEK_SET);    // Reset file pointer to start
    return valid_bits;
}

void free_tree(node_t* root) {
    if (root == NULL) {
        return;
    }
    free_tree(root->left);
    free_tree(root->right);
    free(root);
}



void decompress_file(FILE* in, FILE* out, node_t* root) {
    if (!root) return;

    node_t* current = root;
    unsigned char byte;
    int valid_bits = 8; // Default valid bits per byte
    int num_of_bits = 0;
    int count=0;
    fread(&num_of_bits, sizeof(int), 1, in);
    printf("num_of_bits: %d\n", num_of_bits);
    // Check if the tree is a single-node tree
    int is_single_node = (!root->left && !root->right);

    // Read compressed data
    while (fread(&byte, sizeof(unsigned char), 1, in) == 1) {
        if (feof(in)) {
            // Handle the last byte's padding
            valid_bits = get_valid_bits(in);
        }


        for (int bit_count = 0; bit_count < valid_bits; ++bit_count) {
            // Handle single-node tree (all bits map to the single character)
            if (is_single_node) {
                fputc(root->index, out);
                continue;
            }

            // Get current bit
            int bit = (byte >> (7 - bit_count)) & 1;
            count ++;
            printf("%d\n", count);
            // Traverse the Huffman tree
            if (bit == 0) {
                current = current->left;
            } else {
                current = current->right;
            }

            // If we reach a leaf node, write the character
            if (!current->left && !current->right) {
                if(count <= num_of_bits) {
                    fputc(current->index, out);
                }
                current = root; // Reset to the root for the next character
            }
        }
    }
}




void decode(char *iFile, char *oFile) {
    // Step 1: Open the input (.huf) and output files
    FILE *in = fopen(iFile, "rb");
    if (!in) {
        perror("Error opening input file");
        return;
    }

    FILE *out = fopen(oFile, "w");
    if (!out) {
        perror("Error opening output file");
        fclose(in);
        return;
    }

    // Step 2: Reconstruct the Huffman tree
    node_t *root = read_tree(in);
    if (!root) {
        fprintf(stderr, "Failed to reconstruct Huffman tree\n");
        fclose(in);
        fclose(out);
        return;
    }

    // Step 3: Read and decode the bitstream
    decompress_file(in, out, root);

    // Step 4: Clean up
    free_tree(root); // Free the memory used by the Huffman tree
    fclose(in);
    fclose(out);
}



int main(int argc, char **argv) {
encode("Test.txt", "found.txt");
    decode("output.huf", "final.txt");
    // if (argc != 4) {
    //     fprintf(stderr,
    //             "USAGE: ./huffman [encode | decode] "
    //             "<input file> <output file>\n");
    //     return 0;
    // }
    //
    // int i =0;
    //
    // initialize();
    //
    // if (strcmp(argv[1], "encode") == 0)
    //     encode(argv[2], argv[3]);
    // else if (strcmp(argv[1], "decode") == 0)
    //     decode(argv[2], argv[3]);
    // else
    //     fprintf(stderr,
    //             "USAGE: ./huffman [encode | decode] "
    //             "<input file> <output file>\n");
    //
    // free_memory();

    return 0;
}



